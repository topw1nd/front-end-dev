import {defineField, defineType} from 'sanity'

export default {
    name: 'video',
    title: 'Video',
    type: 'object',
    fields: [
        defineField({
            name: 'caption',
            title: 'Caption',
            type: 'string',
        }),
        defineField({
            name: 'metadata',
            title: 'Metadata',
            // type: 'urlWithMetadata',
            type: 'string',
        }),
    ],
}